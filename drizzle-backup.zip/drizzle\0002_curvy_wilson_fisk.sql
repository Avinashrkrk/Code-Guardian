DROP TABLE "accounts" CASCADE;--> statement-breakpoint
DROP TABLE "repositories" CASCADE;--> statement-breakpoint
DROP TABLE "review_jobs" CASCADE;--> statement-breakpoint
DROP TABLE "users" CASCADE;